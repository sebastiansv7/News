
import { z } from 'zod';
import { insertStorySchema, stories } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  stories: {
    list: {
      method: 'GET' as const,
      path: '/api/stories',
      input: z.object({
        limit: z.coerce.number().optional(),
        source: z.string().optional(),
        ticker: z.string().optional(),
        search: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof stories.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/stories/:id',
      responses: {
        200: z.custom<typeof stories.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    stats: {
      method: 'GET' as const,
      path: '/api/stats',
      responses: {
        200: z.object({
          totalStories: z.number(),
          sources: z.array(z.object({ name: z.string(), count: z.number() })),
        }),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
