
import { db } from "./db";
import { stories, type Story, type InsertStory } from "@shared/schema";
import { eq, desc, ilike, and, sql } from "drizzle-orm";

export interface IStorage {
  getStories(params?: { limit?: number; source?: string; ticker?: string; search?: string }): Promise<Story[]>;
  getStory(id: number): Promise<Story | undefined>;
  getStoryByCanonicalId(storyId: string): Promise<Story | undefined>;
  createStory(story: InsertStory): Promise<Story>;
  getStats(): Promise<{ totalStories: number; sources: { name: string; count: number }[] }>;
}

export class DatabaseStorage implements IStorage {
  async getStories(params?: { limit?: number; source?: string; ticker?: string; search?: string }): Promise<Story[]> {
    const conditions = [];
    
    if (params?.source) {
      conditions.push(eq(stories.source, params.source));
    }
    
    // Simple ticker search in array
    if (params?.ticker) {
      conditions.push(sql`${params.ticker} = ANY(${stories.tickers})`);
    }

    if (params?.search) {
      conditions.push(ilike(stories.headline, `%${params.search}%`));
    }

    return await db.select()
      .from(stories)
      .where(and(...conditions))
      .orderBy(desc(stories.publishedAt))
      .limit(params?.limit || 50);
  }

  async getStory(id: number): Promise<Story | undefined> {
    const [story] = await db.select().from(stories).where(eq(stories.id, id));
    return story;
  }

  async getStoryByCanonicalId(storyId: string): Promise<Story | undefined> {
    const [story] = await db.select().from(stories).where(eq(stories.storyId, storyId));
    return story;
  }

  async createStory(insertStory: InsertStory): Promise<Story> {
    const [story] = await db.insert(stories).values(insertStory).returning();
    return story;
  }

  async getStats(): Promise<{ totalStories: number; sources: { name: string; count: number }[] }> {
    const totalResult = await db.select({ count: sql<number>`count(*)` }).from(stories);
    const totalStories = Number(totalResult[0]?.count || 0);

    const sourcesResult = await db.select({
      name: stories.source,
      count: sql<number>`count(*)`
    })
    .from(stories)
    .groupBy(stories.source);

    return {
      totalStories,
      sources: sourcesResult.map(r => ({ name: r.name, count: Number(r.count) }))
    };
  }
}

export const storage = new DatabaseStorage();
