
import { storage } from "./storage";
import { InsertStory } from "@shared/schema";
import { randomUUID } from "crypto";

// Mock data for fallback
const MOCK_STORIES: Partial<InsertStory>[] = [
  {
    headline: "SEC Files Charges Against Crypto Exchange",
    body: "The Securities and Exchange Commission today charged...",
    source: "SEC.gov",
    urgency: 90,
    tickers: ["COIN", "BTC"],
  },
  {
    headline: "NASDAQ Composite hits new all-time high",
    body: "Tech stocks rallied today as the composite index...",
    source: "NASDAQ",
    urgency: 50,
    tickers: ["QQQ", "AAPL", "NVDA"],
  },
  {
    headline: "Fed Chair Jerome Powell to speak at Economic Club",
    body: "Markets await signals on interest rate cuts...",
    source: "Finnhub",
    urgency: 75,
    tickers: ["SPY", "USD"],
  },
  {
    headline: "Oil prices surge amid geopolitical tensions",
    body: "Crude oil futures rose 2% following reports of...",
    source: "GDELT",
    urgency: 60,
    tickers: ["XLE", "USO"],
  }
];

// Helper to simulate fetching from an API
async function fetchMockFeed(source: string): Promise<InsertStory[]> {
  // In a real implementation, this would use fetch() to call the URLs from the text file.
  // For MVP stability and speed, we generate semi-random data based on the "Mock" templates.
  
  const template = MOCK_STORIES.find(s => s.source === source) || MOCK_STORIES[0];
  const newStory: InsertStory = {
    storyId: randomUUID(),
    headline: `${template.headline} - ${new Date().toLocaleTimeString()}`,
    body: `${template.body} (Live update from ${source})`,
    source: source,
    urgency: template.urgency || 50,
    tickers: template.tickers || [],
    publishedAt: new Date(),
  };
  return [newStory];
}

async function runIngestCycle() {
  console.log("Running ingestion cycle...");
  const sources = ["SEC.gov", "NASDAQ", "Finnhub", "GDELT"];
  
  for (const source of sources) {
    try {
      const stories = await fetchMockFeed(source);
      for (const story of stories) {
        // Simple dedup check (though our random ID makes it unique, in real life we'd check external ID)
        await storage.createStory(story);
      }
    } catch (err) {
      console.error(`Failed to ingest from ${source}:`, err);
    }
  }
}

export function startIngestionService() {
  // Run immediately
  runIngestCycle();
  
  // Poll every 10 seconds to simulate a busy feed
  setInterval(runIngestCycle, 10000);
}
