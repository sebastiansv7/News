
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { startIngestionService } from "./ingest";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.stories.list.path, async (req, res) => {
    try {
      const params = api.stories.list.input?.parse(req.query);
      const stories = await storage.getStories(params);
      res.json(stories);
    } catch (err) {
      res.status(400).json({ message: "Invalid query params" });
    }
  });

  app.get(api.stories.get.path, async (req, res) => {
    const story = await storage.getStory(Number(req.params.id));
    if (!story) {
      return res.status(404).json({ message: 'Story not found' });
    }
    res.json(story);
  });

  app.get(api.stories.stats.path, async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  // Start the background ingestion service
  startIngestionService();

  return httpServer;
}
