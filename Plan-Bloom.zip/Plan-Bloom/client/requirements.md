## Packages
recharts | For analytics charts (pie chart for sources, bar chart for volume)
date-fns | For relative time formatting (e.g., "5 mins ago")
framer-motion | For smooth entry animations and transitions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}
