import { useState } from "react";
import { useStories } from "@/hooks/use-stories";
import { StoryCard } from "@/components/StoryCard";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, Filter, RefreshCw } from "lucide-react";

export default function Home() {
  const [search, setSearch] = useState("");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  
  const { data: stories, isLoading, isError, isRefetching } = useStories({ 
    search: search || undefined,
    source: sourceFilter === "all" ? undefined : sourceFilter
  });

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <Sidebar />
      <Header onSearch={setSearch} searchValue={search} />
      
      <main className="md:pl-64 pt-6 pb-20">
        <div className="container mx-auto px-6 max-w-7xl">
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4">
            <div>
              <h2 className="text-2xl font-display font-bold text-foreground flex items-center gap-3">
                Market Feed
                {isRefetching && <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />}
              </h2>
              <p className="text-muted-foreground text-sm mt-1">Real-time financial news aggregation engine</p>
            </div>
            
            <div className="flex items-center gap-3 w-full md:w-auto">
              <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-secondary/30 border border-border/50 text-xs font-mono text-muted-foreground">
                <Filter className="w-3 h-3" />
                <span className="hidden sm:inline">FILTER SOURCE:</span>
              </div>
              
              <Select value={sourceFilter} onValueChange={setSourceFilter}>
                <SelectTrigger className="w-[180px] h-10 bg-card border-border/50 text-sm font-medium">
                  <SelectValue placeholder="All Sources" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sources</SelectItem>
                  <SelectItem value="Reuters">Reuters</SelectItem>
                  <SelectItem value="Bloomberg">Bloomberg</SelectItem>
                  <SelectItem value="WSJ">Wall Street Journal</SelectItem>
                  <SelectItem value="CNBC">CNBC</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {isError && (
            <div className="bg-destructive/10 border border-destructive/20 text-destructive p-6 rounded-lg flex items-center gap-3 mb-8">
              <AlertCircle className="w-6 h-6" />
              <div>
                <h3 className="font-bold">Connection Error</h3>
                <p className="text-sm opacity-80">Failed to load live feed. Retrying...</p>
              </div>
            </div>
          )}

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(9)].map((_, i) => (
                <div key={i} className="space-y-3 p-4 border border-border/30 rounded-lg bg-card/30">
                  <Skeleton className="h-4 w-20 rounded" />
                  <Skeleton className="h-8 w-full rounded" />
                  <Skeleton className="h-20 w-full rounded" />
                  <div className="flex gap-2 pt-2">
                    <Skeleton className="h-6 w-16 rounded" />
                    <Skeleton className="h-6 w-16 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : stories && stories.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {stories.map((story, index) => (
                <StoryCard key={story.id} story={story} index={index} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-border rounded-xl bg-card/20">
              <div className="w-16 h-16 rounded-full bg-secondary/50 flex items-center justify-center mb-4 text-muted-foreground">
                <Newspaper className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-display font-bold text-foreground">No stories found</h3>
              <p className="text-muted-foreground max-w-sm mt-2">
                Try adjusting your search filters or wait for new incoming stories.
              </p>
            </div>
          )}
          
        </div>
      </main>
    </div>
  );
}
