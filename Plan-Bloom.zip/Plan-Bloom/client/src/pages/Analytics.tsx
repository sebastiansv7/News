import { useStats } from "@/hooks/use-stories";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, BarChart3, PieChart as PieIcon, Activity } from "lucide-react";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell 
} from 'recharts';
import { useState } from "react";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function Analytics() {
  const { data: stats, isLoading, isError } = useStats();
  const [searchValue, setSearchValue] = useState("");

  const chartData = stats?.sources.map(s => ({
    name: s.name,
    value: s.count
  })).sort((a, b) => b.value - a.value);

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <Sidebar />
      <Header onSearch={setSearchValue} searchValue={searchValue} />
      
      <main className="md:pl-64 pt-6 pb-20">
        <div className="container mx-auto px-6 max-w-7xl">
          <div className="mb-8">
            <h2 className="text-2xl font-display font-bold text-foreground flex items-center gap-3">
              <Activity className="w-6 h-6 text-primary" />
              Market Analytics
            </h2>
            <p className="text-muted-foreground text-sm mt-1">Data aggregation statistics and source volume analysis</p>
          </div>

          {isError && (
            <div className="bg-destructive/10 border border-destructive/20 text-destructive p-6 rounded-lg flex items-center gap-3 mb-8">
              <AlertCircle className="w-6 h-6" />
              <div>
                <h3 className="font-bold">Error</h3>
                <p className="text-sm opacity-80">Failed to load analytics data.</p>
              </div>
            </div>
          )}

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Skeleton className="h-[400px] w-full rounded-xl" />
              <Skeleton className="h-[400px] w-full rounded-xl" />
            </div>
          ) : (
            <div className="space-y-8">
              {/* Key Metrics Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="bg-card border-border/50 shadow-lg">
                  <CardContent className="pt-6">
                    <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-1">Total Stories</div>
                    <div className="text-3xl font-bold font-display text-primary">{stats?.totalStories.toLocaleString()}</div>
                    <div className="text-xs text-emerald-500 font-medium mt-1">▲ 12% from yesterday</div>
                  </CardContent>
                </Card>
                
                <Card className="bg-card border-border/50 shadow-lg">
                  <CardContent className="pt-6">
                    <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-1">Active Sources</div>
                    <div className="text-3xl font-bold font-display text-foreground">{stats?.sources.length}</div>
                    <div className="text-xs text-muted-foreground mt-1">Across 4 regions</div>
                  </CardContent>
                </Card>
                
                <Card className="bg-card border-border/50 shadow-lg">
                  <CardContent className="pt-6">
                    <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-1">Processing Rate</div>
                    <div className="text-3xl font-bold font-display text-foreground">42<span className="text-sm text-muted-foreground ml-1">/min</span></div>
                    <div className="text-xs text-emerald-500 font-medium mt-1">Optimal performance</div>
                  </CardContent>
                </Card>
                
                <Card className="bg-card border-border/50 shadow-lg">
                  <CardContent className="pt-6">
                    <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-1">Alert Triggers</div>
                    <div className="text-3xl font-bold font-display text-amber-500">8</div>
                    <div className="text-xs text-muted-foreground mt-1">Last 24 hours</div>
                  </CardContent>
                </Card>
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-card border-border/50 shadow-lg col-span-1">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <PieIcon className="w-5 h-5 text-primary" />
                      Stories Distribution by Source
                    </CardTitle>
                    <CardDescription>Volume share across integrated news providers</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={chartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {chartData?.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="rgba(0,0,0,0.2)" />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                          itemStyle={{ color: 'hsl(var(--foreground))' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border/50 shadow-lg col-span-1">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <BarChart3 className="w-5 h-5 text-primary" />
                      Source Volume Comparison
                    </CardTitle>
                    <CardDescription>Absolute number of stories ingested per source</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={chartData}
                        layout="vertical"
                        margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="rgba(255,255,255,0.1)" />
                        <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                        <YAxis dataKey="name" type="category" stroke="hsl(var(--muted-foreground))" fontSize={12} width={80} />
                        <Tooltip 
                          cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                          itemStyle={{ color: 'hsl(var(--foreground))' }}
                        />
                        <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={24} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
