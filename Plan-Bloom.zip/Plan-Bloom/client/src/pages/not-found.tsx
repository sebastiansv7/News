import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground p-4">
      <Card className="w-full max-w-md border-border/50 bg-card shadow-2xl">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-destructive" />
            <h1 className="text-2xl font-display font-bold">404 Page Not Found</h1>
          </div>

          <p className="mt-4 text-sm text-muted-foreground font-mono">
            ERR_ROUTE_MISSING: The requested resource could not be located in the system registry.
          </p>
          
          <div className="mt-8 bg-secondary/30 p-4 rounded border border-border/50 font-mono text-xs text-muted-foreground">
            <p>System Diagnostic:</p>
            <p className="mt-2 text-red-400">{`> Path verification failed`}</p>
            <p className="text-red-400">{`> Resource unlinked`}</p>
            <p className="mt-2">{`> Suggestions: Return to dashboard`}</p>
          </div>

          <div className="mt-6 flex justify-end">
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Return to Dashboard
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
