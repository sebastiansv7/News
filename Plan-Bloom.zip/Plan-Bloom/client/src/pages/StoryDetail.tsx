import { useRoute, Link } from "wouter";
import { useStory } from "@/hooks/use-stories";
import { Sidebar } from "@/components/Sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, Share2, Printer, Bookmark, Clock, Globe } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";

export default function StoryDetail() {
  const [, params] = useRoute("/story/:id");
  const id = params ? parseInt(params.id) : 0;
  
  const { data: story, isLoading, isError } = useStory(id);

  if (isLoading) return <LoadingState />;
  if (isError || !story) return <ErrorState />;

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <Sidebar />
      
      <main className="md:pl-64 min-h-screen">
        <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border h-16 flex items-center px-6 justify-between">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-foreground">
              <ChevronLeft className="w-4 h-4" />
              Back to Feed
            </Button>
          </Link>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="hidden sm:flex gap-2 h-9">
              <Printer className="w-3.5 h-3.5" />
              Print
            </Button>
            <Button variant="outline" size="sm" className="hidden sm:flex gap-2 h-9">
              <Share2 className="w-3.5 h-3.5" />
              Share
            </Button>
            <Button size="sm" className="gap-2 h-9">
              <Bookmark className="w-3.5 h-3.5" />
              Save Story
            </Button>
          </div>
        </div>

        <div className="container mx-auto px-6 py-10 max-w-4xl">
          <div className="mb-6 flex items-center gap-3 flex-wrap">
            <Badge variant="outline" className="text-sm py-1 font-mono uppercase tracking-wider text-muted-foreground border-muted-foreground/30">
              {story.source}
            </Badge>
            {story.urgency && story.urgency >= 5 && (
              <Badge variant="default" className="bg-destructive hover:bg-destructive/90 text-white border-none text-xs font-bold py-1">
                HIGH PRIORITY
              </Badge>
            )}
            <div className="ml-auto text-sm font-mono text-muted-foreground flex items-center gap-2">
              <Clock className="w-3.5 h-3.5" />
              {format(new Date(story.publishedAt), "PPP p")} 
              <span className="opacity-50 mx-1">|</span>
              {formatDistanceToNow(new Date(story.publishedAt), { addSuffix: true })}
            </div>
          </div>

          <h1 className="text-3xl md:text-5xl font-display font-bold leading-tight mb-8 text-foreground">
            {story.headline}
          </h1>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-8 space-y-6">
              <div className="prose prose-invert prose-lg max-w-none prose-headings:font-display prose-headings:tracking-wide prose-p:leading-relaxed prose-p:text-gray-300">
                <p className="text-xl leading-relaxed text-foreground/90 font-medium border-l-4 border-primary pl-4 py-1 mb-8">
                  {story.body.substring(0, 120)}...
                </p>
                <div className="whitespace-pre-wrap font-serif text-lg leading-loose">
                  {story.body}
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 space-y-6">
              <div className="p-5 rounded-lg border border-border bg-card/40 shadow-sm">
                <h3 className="text-sm font-mono uppercase tracking-widest text-muted-foreground mb-4">Related Tickers</h3>
                <div className="flex flex-wrap gap-2">
                  {story.tickers?.map(ticker => (
                    <Link key={ticker} href={`/?ticker=${ticker}`}>
                      <Badge variant="secondary" className="px-3 py-1.5 cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors font-mono">
                        ${ticker}
                      </Badge>
                    </Link>
                  ))}
                  {(!story.tickers || story.tickers.length === 0) && (
                    <span className="text-sm text-muted-foreground italic">No tickers linked</span>
                  )}
                </div>
              </div>

              <div className="p-5 rounded-lg border border-border bg-card/40 shadow-sm">
                <h3 className="text-sm font-mono uppercase tracking-widest text-muted-foreground mb-4">Meta Information</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between py-2 border-b border-border/30">
                    <span className="text-muted-foreground">Story ID</span>
                    <span className="font-mono">{story.storyId}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border/30">
                    <span className="text-muted-foreground">Source Origin</span>
                    <span className="font-mono flex items-center gap-1">
                      <Globe className="w-3 h-3" /> API Feed
                    </span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border/30">
                    <span className="text-muted-foreground">Urgency Score</span>
                    <span className="font-mono">{story.urgency ?? 0}/10</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="md:pl-64 pt-16 px-6 container max-w-4xl mx-auto space-y-8">
        <Skeleton className="h-8 w-32" />
        <Skeleton className="h-20 w-full" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
          <Skeleton className="h-64 w-full rounded-lg" />
        </div>
      </main>
    </div>
  );
}

function ErrorState() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold text-destructive">Error Loading Story</h2>
        <p className="text-muted-foreground">The requested story could not be found or has been removed.</p>
        <Link href="/">
          <Button>Return to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
}
