import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Story } from "@shared/schema";

// Type for stats response since it's defined inline in routes
type StatsResponse = {
  totalStories: number;
  sources: { name: number; count: number }[];
};

export function useStories(filters?: { 
  search?: string; 
  source?: string; 
  ticker?: string; 
  limit?: number; 
}) {
  return useQuery({
    queryKey: [api.stories.list.path, filters],
    queryFn: async () => {
      // Build query params
      const params: Record<string, string | number> = {};
      if (filters?.search) params.search = filters.search;
      if (filters?.source && filters.source !== "all") params.source = filters.source;
      if (filters?.ticker) params.ticker = filters.ticker;
      if (filters?.limit) params.limit = filters.limit;

      // Construct URL with query params
      const url = new URL(api.stories.list.path, window.location.origin);
      Object.entries(params).forEach(([key, value]) => 
        url.searchParams.append(key, String(value))
      );

      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch stories");
      
      return api.stories.list.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Poll every 5 seconds for live updates
  });
}

export function useStory(id: number) {
  return useQuery({
    queryKey: [api.stories.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.stories.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch story");
      return api.stories.get.responses[200].parse(await res.json());
    },
  });
}

export function useStats() {
  return useQuery({
    queryKey: [api.stories.stats.path],
    queryFn: async () => {
      const res = await fetch(api.stories.stats.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch stats");
      // Use the Zod schema to parse validation, though we need to be careful with exact type matching
      return api.stories.stats.responses[200].parse(await res.json());
    },
  });
}
