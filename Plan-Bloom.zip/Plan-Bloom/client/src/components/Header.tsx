import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  onSearch: (value: string) => void;
  searchValue: string;
}

export function Header({ onSearch, searchValue }: HeaderProps) {
  return (
    <header className="h-16 border-b border-border bg-background/80 backdrop-blur-md sticky top-0 z-10 flex items-center justify-between px-6 md:pl-72">
      <div className="flex items-center gap-4 flex-1 max-w-xl">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search headlines, tickers (e.g. $AAPL), or keywords..." 
            className="pl-10 bg-secondary/30 border-border/50 focus:border-primary/50 focus:ring-primary/20 h-10 font-mono text-sm"
            value={searchValue}
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>
      </div>
      
      <div className="flex items-center gap-4 ml-4">
        <div className="hidden md:flex items-center gap-6 text-xs font-mono text-muted-foreground border-l border-border pl-6 h-8">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground/60">S&P 500</span>
            <span className="text-emerald-500 font-bold">4,783.45 ▲ 0.4%</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground/60">NASDAQ</span>
            <span className="text-emerald-500 font-bold">15,124.20 ▲ 0.8%</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground/60">VIX</span>
            <span className="text-rose-500 font-bold">13.45 ▼ 2.1%</span>
          </div>
        </div>
        
        <Badge variant="outline" className="hidden sm:flex h-8 px-3 font-mono bg-primary/10 text-primary border-primary/20">
          LIVE
        </Badge>
      </div>
    </header>
  );
}
