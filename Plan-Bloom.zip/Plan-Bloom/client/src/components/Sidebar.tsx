import { Link, useLocation } from "wouter";
import { LayoutDashboard, Newspaper, PieChart, Rss, Bell, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { icon: Newspaper, label: "Live Feed", href: "/" },
    { icon: PieChart, label: "Market Analytics", href: "/analytics" },
    { icon: Rss, label: "Data Sources", href: "/sources" },
    { icon: Bell, label: "Alerts", href: "/alerts" },
  ];

  return (
    <aside className="w-64 border-r border-border bg-card/50 flex flex-col h-screen fixed left-0 top-0 z-20 backdrop-blur-md hidden md:flex">
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground font-bold font-display shadow-lg shadow-primary/20">
            ND
          </div>
          <div>
            <h1 className="text-lg font-bold font-display tracking-wider text-foreground">NewsDesk</h1>
            <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest">Financial Terminal</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        <p className="px-4 text-xs font-mono text-muted-foreground uppercase tracking-widest mb-4 mt-2">Main Menu</p>
        
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 group",
              isActive 
                ? "bg-primary/10 text-primary border border-primary/20 shadow-sm" 
                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            )}>
              <item.icon className={cn(
                "w-5 h-5 transition-colors",
                isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
              )} />
              {item.label}
              {isActive && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              )}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border/50">
        <Link href="/settings" className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all">
          <Settings className="w-5 h-5" />
          System Settings
        </Link>
        <div className="mt-4 px-4 py-3 bg-secondary/30 rounded-lg border border-border/50">
          <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            System Online
          </div>
          <div className="text-[10px] text-muted-foreground/60 font-mono mt-1">
            Latency: 24ms
          </div>
        </div>
      </div>
    </aside>
  );
}
