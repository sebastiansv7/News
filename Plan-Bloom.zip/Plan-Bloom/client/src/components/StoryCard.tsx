import { type Story } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Clock, ExternalLink, Zap } from "lucide-react";
import { Link } from "wouter";

interface StoryCardProps {
  story: Story;
  index?: number;
}

export function StoryCard({ story, index = 0 }: StoryCardProps) {
  const getUrgencyColor = (urgency: number | null) => {
    if (!urgency) return "bg-slate-700 hover:bg-slate-600";
    if (urgency >= 8) return "bg-red-600 hover:bg-red-500 animate-pulse";
    if (urgency >= 5) return "bg-amber-500 hover:bg-amber-400";
    return "bg-blue-600 hover:bg-blue-500";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
    >
      <Link href={`/story/${story.id}`} className="block group h-full">
        <Card className="h-full terminal-card p-4 hover:bg-secondary/10 cursor-pointer flex flex-col gap-3 relative overflow-hidden">
          {/* Subtle accent border on left based on urgency */}
          <div className={`absolute left-0 top-0 bottom-0 w-1 ${story.urgency && story.urgency >= 8 ? 'bg-destructive' : 'bg-primary/20'}`} />

          <div className="flex items-start justify-between gap-4 pl-2">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="outline" className="text-[10px] h-5 font-mono uppercase tracking-wider text-muted-foreground border-muted-foreground/30">
                  {story.source}
                </Badge>
                {story.urgency && story.urgency > 0 && (
                  <Badge className={`text-[10px] h-5 font-bold border-none ${getUrgencyColor(story.urgency)} text-white`}>
                    <Zap className="w-3 h-3 mr-1 fill-current" />
                    LEVEL {story.urgency}
                  </Badge>
                )}
              </div>
              
              <h3 className="text-lg leading-snug font-display text-foreground group-hover:text-primary transition-colors">
                {story.headline}
              </h3>
            </div>
            
            <div className="flex items-center text-xs text-muted-foreground whitespace-nowrap font-mono shrink-0">
              <Clock className="w-3 h-3 mr-1.5" />
              {formatDistanceToNow(new Date(story.publishedAt), { addSuffix: true })}
            </div>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2 pl-2 font-normal leading-relaxed">
            {story.body}
          </p>

          <div className="mt-auto pt-2 pl-2 flex flex-wrap gap-2">
            {story.tickers?.slice(0, 4).map((ticker) => (
              <span key={ticker} className="ticker-tape group-hover:border-primary/40 group-hover:text-primary transition-colors">
                ${ticker}
              </span>
            ))}
            {story.tickers && story.tickers.length > 4 && (
              <span className="text-xs text-muted-foreground flex items-center">
                +{story.tickers.length - 4} more
              </span>
            )}
          </div>
        </Card>
      </Link>
    </motion.div>
  );
}
